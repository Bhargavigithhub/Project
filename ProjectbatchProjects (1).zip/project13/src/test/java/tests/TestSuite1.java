package tests;

import static utils.FrameworkUtils.driver;

import org.junit.Test;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;
import pages.HomePage;
import pages.ResultsPage;

public class TestSuite1 {

	@Test
	public void test() {
		// open browser
		WebDriverManager.chromedriver().setup();
		driver= new ChromeDriver();
		// invoke app
		driver.get("https://www.amazon.in/");
		// maximize browser
		driver.manage().window().maximize();
		// perform search
		HomePage.performSearch();
		
		// verify search
		ResultsPage.verfySearch();
		
		// kill browser
		driver.quit();

	}

}
