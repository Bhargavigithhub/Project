package utils;

import org.openqa.selenium.WebDriver;

public class FrameworkUtils {
	
	public static WebDriver driver; 

}
