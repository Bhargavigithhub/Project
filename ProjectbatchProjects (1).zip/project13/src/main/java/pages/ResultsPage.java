package pages;

import static utils.FrameworkUtils.*;

import org.openqa.selenium.By;

public class ResultsPage {
	
	public static By resultspage_txt_shoes=By.xpath("(//span[contains(text(),'\"shoes\"')])[1]");

	public static void verfySearch() {
		if (driver.findElement(resultspage_txt_shoes).isDisplayed()) {
			System.out.println("passed");
		} else {
			System.out.println("Failed");
		}
		
	}
}
