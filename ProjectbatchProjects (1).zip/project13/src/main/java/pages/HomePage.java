package pages;

import org.openqa.selenium.By;
import static utils.FrameworkUtils.*;

public class HomePage {
	
	public static By homepage_edit_search=By.xpath("//input[@id=\"twotabsearchtextbox\"]");

	public static void performSearch() {
		driver.findElement(homepage_edit_search).sendKeys("shoes");
		driver.findElement(homepage_edit_search).submit();
	}
	
}
