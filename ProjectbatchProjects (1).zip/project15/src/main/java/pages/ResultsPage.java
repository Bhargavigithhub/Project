package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ResultsPage {
	public WebDriver driver;

	public ResultsPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="(//span[contains(text(),'\\\"shoes\\\"')])[1]")
	public WebElement resultspage_txt_shoes;

	public void verfySearch() {
		if (resultspage_txt_shoes.isDisplayed()) {
			System.out.println("passed");
		} else {
			System.out.println("Failed");
		}
		
	}
}
