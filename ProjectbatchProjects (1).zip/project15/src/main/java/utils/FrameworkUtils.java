package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;

public class FrameworkUtils {
	
	public static WebDriver driver;
	public static Properties prop;

	public static void loadProperties() throws Exception, IOException {
		String projectPath=System.getProperty("user.dir");
		String path=projectPath+"/src/main/resources/config/global.properties";
		prop= new Properties();
		prop.load(new FileInputStream(new File(path)));
		
	} 

}
