package utils;

import static utils.FrameworkUtils.driver;
import static utils.FrameworkUtils.prop;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BrowserUtils {

	public static void openBrowser() {
		String browser = prop.getProperty("browser");
		switch (browser) {
		case "chrome":
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		case "edge":
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
			break;
		case "ff":
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			break;

		default:
			System.out.println("browser is not supportive");
			break;
		}

	}

	public static void invokeApp() {
		driver.get(FrameworkUtils.prop.getProperty("url"));

	}

	public static void maximizeBrowser() {
		driver.manage().window().maximize();

	}

	public static void killBrowser() {
		driver.quit();

	}

}
