package tests;

import static utils.FrameworkUtils.driver;
import static utils.FrameworkUtils.loadProperties;

import org.junit.Test;

import pages.HomePage;
import pages.ResultsPage;
import utils.BrowserUtils;

public class TestSuite1 {

	@Test
	public void test() throws Exception {
		loadProperties();
		BrowserUtils.openBrowser();
		BrowserUtils.invokeApp();
		BrowserUtils.maximizeBrowser();
		new HomePage(driver).performSearch();
		new ResultsPage(driver).verfySearch();
		driver.quit();

	}

}
