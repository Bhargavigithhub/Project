package objectrepo;

import org.openqa.selenium.By;

public class Locators {
	public static By homepage_edit_search=By.xpath("//input[@id=\"twotabsearchtextbox\"]");
	public static By resultspage_txt_shoes=By.xpath("(//span[contains(text(),'\"shoes\"')])[1]");
}
