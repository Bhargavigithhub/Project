package tests;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Locatable;

import io.github.bonigarcia.wdm.WebDriverManager;
import objectrepo.Locators;

public class TestSuite1 {

	@Test
	public void test() {
		//open browser
		WebDriverManager.chromedriver().setup();
		WebDriver driver= new ChromeDriver();
		//invoke app
		driver.get("https://www.amazon.in/");
		//maximize browser
		driver.manage().window().maximize();
		//perform search
		driver.findElement(Locators.homepage_edit_search).sendKeys("shoes");
		driver.findElement(Locators.homepage_edit_search).submit();
		// verify search
		if(driver.findElement(Locators.resultspage_txt_shoes).isDisplayed()) {
			System.out.println("passed");
		}else {
			System.out.println("Failed");
		}
		//kill browser
		driver.quit();
	
	}

}
