package testsset2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;

public class SampleTest12 {
	
	public static void main(String args[]) throws Exception, IOException {
		
		String path="C:\\Users\\suman\\eclipse-workspace9997777\\project12\\src\\test\\resources\\testdata\\data_txt.txt";
		String res=FileUtils.readFileToString(new File(path));
		System.out.println(res);
		
	}

}
