package testsset2;



public class SampleTest11 {
	
	public static void main(String args[]) throws Exception, IOException {
		
		String path="C:\\Users\\suman\\eclipse-workspace9997777\\project12\\src\\main\\resources\\config\\global.properties";
		Properties prop=new Properties();
		File file= new File(path);
		FileInputStream fi=new FileInputStream(file);
		prop.load(fi);
		System.out.println(prop.getProperty("execution"));
		
		
	}

}
